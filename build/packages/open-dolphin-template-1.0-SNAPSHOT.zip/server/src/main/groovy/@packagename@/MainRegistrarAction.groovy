package ${packagename}

import org.opendolphin.core.server.DTO
import org.opendolphin.core.server.Slot
import org.opendolphin.core.server.action.DolphinServerAction
import org.opendolphin.core.server.comm.ActionRegistry

class MainRegistrarAction extends DolphinServerAction {

	void registerIn(ActionRegistry registry) {

	}
}
