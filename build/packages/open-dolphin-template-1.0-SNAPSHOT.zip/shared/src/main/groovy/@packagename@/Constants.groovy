package ${packagename}

class Constants {
}
